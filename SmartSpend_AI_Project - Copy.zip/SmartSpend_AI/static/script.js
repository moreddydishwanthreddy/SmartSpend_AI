const transactions = [];
let expenseChart = null;
const money = value => new Intl.NumberFormat("en-IN", {style:"currency", currency:"INR"}).format(value);

document.getElementById("today").textContent = new Date().toLocaleDateString("en-IN", {day:"numeric", month:"short", year:"numeric"});

function render() {
  const income = transactions.filter(t=>t.type==="income").reduce((s,t)=>s+t.amount,0);
  const expense = transactions.filter(t=>t.type==="expense").reduce((s,t)=>s+t.amount,0);
  document.getElementById("total-income").textContent = money(income);
  document.getElementById("total-expense").textContent = money(expense);
  document.getElementById("total-balance").textContent = money(income-expense);
  document.getElementById("transaction-count").textContent = `${transactions.length} records`;
  const tbody = document.getElementById("transaction-list");
  if (!transactions.length) {
    tbody.innerHTML = '<tr><td colspan="6" class="empty-row">No transactions yet. Add your first transaction above.</td></tr>';
  } else {
    tbody.innerHTML = transactions.map((t,i)=>`<tr><td>${escapeHtml(t.description)}</td><td>${escapeHtml(t.category)}</td><td><span class="type-pill type-${t.type}">${t.type}</span></td><td>${t.date}</td><td class="right">${t.type==="expense"?"−":"+"}${money(t.amount)}</td><td><button class="delete-btn" data-index="${i}" aria-label="Delete transaction">×</button></td></tr>`).reverse().join("");
  }
  updateChart();
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
}
function updateChart() {
  const totals = {};
  transactions.filter(t=>t.type==="expense").forEach(t=>totals[t.category]=(totals[t.category]||0)+t.amount);
  const labels = Object.keys(totals);
  document.getElementById("chart-empty").style.display = labels.length ? "none" : "block";
  const ctx = document.getElementById("expenseChart");
  if (expenseChart) expenseChart.destroy();
  if (labels.length) expenseChart = new Chart(ctx,{type:"doughnut",data:{labels,datasets:[{data:Object.values(totals),backgroundColor:["#766be8","#39b99a","#f1a36b","#5e9bd8","#e17c9a","#a18adf","#80b8c2"],borderWidth:0,hoverOffset:5}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:"bottom",labels:{usePointStyle:true,boxWidth:7,padding:15,font:{size:10}}}}}});
}
document.getElementById("transaction-form").addEventListener("submit", event=>{
  event.preventDefault();
  const description=document.getElementById("description").value.trim();
  const amount=Number(document.getElementById("amount").value);
  if (!description || !Number.isFinite(amount) || amount<=0) return;
  transactions.push({description,amount,type:document.getElementById("type").value,category:document.getElementById("category").value,date:new Date().toLocaleDateString("en-IN")});
  event.target.reset();
  render();
});
document.getElementById("transaction-list").addEventListener("click", event=>{
  const button=event.target.closest("[data-index]");
  if (!button) return;
  const reversedIndex=Number(button.dataset.index);
  transactions.splice(transactions.length-1-reversedIndex,1);
  render();
});
document.getElementById("ai-button").addEventListener("click", async ()=>{
  const button=document.getElementById("ai-button"), result=document.getElementById("ai-result");
  button.disabled=true; button.textContent="Thinking...";
  try {
    const response=await fetch("/api/insights",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({transactions})});
    const data=await response.json(); result.textContent=data.insight || "No insight available.";
  } catch(error) { result.textContent="Could not connect to the server. Please try again."; }
  finally {button.disabled=false;button.textContent="Generate insights ✦";}
});
render();
