import os
from datetime import datetime
from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__)

@app.route("/")
def dashboard():
    return render_template("index.html")

@app.route("/api/insights", methods=["POST"])
def insights():
    data = request.get_json(silent=True) or {}
    transactions = data.get("transactions", [])
    if not transactions:
        return jsonify({"insight": "Add a few transactions first. Then ask SmartSpend AI for spending insights."})

    expenses = [t for t in transactions if t.get("type") == "expense"]
    total = sum(float(t.get("amount", 0)) for t in expenses)
    categories = {}
    for item in expenses:
        category = item.get("category", "Other")
        categories[category] = categories.get(category, 0) + float(item.get("amount", 0))

    if not categories:
        summary = "You have not recorded any expenses yet. Add your expenses to receive useful insights."
    else:
        top_category = max(categories, key=categories.get)
        summary = (
            f"You have recorded ₹{total:,.2f} in expenses. "
            f"Your highest-spending category is {top_category} "
            f"(₹{categories[top_category]:,.2f}). "
            "Review this category and consider setting a monthly budget for it."
        )

    # Optional Gemini integration. The app still works without an API key.
    api_key = os.getenv("GEMINI_API_KEY")
    if api_key:
        try:
            from google import genai
            client = genai.Client(api_key=api_key)
            prompt = (
                "Give the student-friendly user 2-3 concise, practical budgeting insights. "
                "Do not shame the user or make assumptions. Use Indian rupees.\n"
                f"Expense summary: {summary}\nCategory totals: {categories}"
            )
            response = client.models.generate_content(
                model="gemini-2.5-flash",
                contents=prompt
            )
            if response.text:
                summary = response.text
        except Exception:
            summary += " (Gemini is not available right now, so this is a basic automatic insight.)"

    return jsonify({"insight": summary})

if __name__ == "__main__":
    app.run(debug=True)
