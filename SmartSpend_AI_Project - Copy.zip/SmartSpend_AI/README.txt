SMARTSPEND AI - BEGINNER SETUP
================================

1. Extract this ZIP file.
2. Open the extracted SmartSpend_AI folder in VS Code.
3. Open Terminal > New Terminal.
4. Create a virtual environment (skip if you already have one):
   python -m venv venv

5. Install packages:
   python -m pip install -r requirements.txt

6. Create your private .env file:
   Copy .env.example and rename the copy to .env.
   If you want Gemini AI responses, add your own Gemini API key in .env.
   Keep your API key private. Do not upload .env to GitHub.

7. Run the website:
   python app.py

8. Open this address in your browser:
   http://127.0.0.1:5000

NOTES
-----
- The expense tracker works without a Gemini API key.
- Without a key, the AI Insights button provides a basic automatic spending summary.
- Transactions are stored in the browser session only and will reset when the page is refreshed.
- This is a learning/college project, not a banking application.
